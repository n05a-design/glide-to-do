"""Glide 3.7: Scrollwege, Seitendetails und Containeranhänge, isoliert getestet."""
import argparse
import copy
from datetime import date, timedelta
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--screenshots', type=Path)
args = parser.parse_args()


def descendants(widget):
    for child in widget.winfo_children():
        yield child
        yield from descendants(child)


with tempfile.TemporaryDirectory(prefix='glide-release37-') as tmp:
    os.environ['GLIDE_DATA_DIR'] = tmp
    loader = importlib.machinery.SourceFileLoader('glide_release37', str(ROOT/'src/glide/app.pyw'))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    root = mod.tk.Tk()
    root.withdraw()
    if os.name == 'nt':
        root.attributes('-alpha', 0.0)
        root.attributes('-toolwindow', True)
    errors = []
    root.report_callback_exception = lambda *e: errors.append(e)
    app = mod.ListApp(root)
    app.show_error = lambda *e, **kw: errors.append(e)
    app.show_warning = lambda *e, **kw: errors.append(e)
    app.show_info = lambda *a, **kw: None
    app.ask_yes_no = lambda *a, **kw: True
    root.geometry('1280x960+10+10')
    root.deiconify()

    def settle():
        root.update()
        root.after(100, root.quit)
        root.mainloop()
        root.update()

    def capture(widget, name):
        if args.screenshots and os.name == 'nt':
            sys.path.insert(0, str(ROOT/'tests/tools'))
            from releasedaten import save_windows_screenshot
            widget.update()
            save_windows_screenshot(widget, args.screenshots.resolve()/f'{name}.png')

    try:
        # Migration sichert die unveränderten alten Bytes außerhalb der Rotation.
        old = (ROOT/'tests/fixtures/current_v11/reference_v11.json').read_bytes()
        Path(mod.SAVE_FILE).write_bytes(old)
        app._schema12_backup_checked = False
        app.load_items()
        assert all(page['attachments'] == [] for page in app.lists + app.folders)
        original_copy = mod.shutil.copy2
        def denied_copy(*a, **kw):
            raise OSError('Test: Sicherungsziel nicht beschreibbar')
        mod.shutil.copy2 = denied_copy
        assert not app.save_items(show_error=False)
        assert Path(mod.SAVE_FILE).read_bytes() == old
        mod.shutil.copy2 = original_copy
        assert app.save_items()
        copies = list(Path(mod.BACKUP_DIR).glob('liste_vor_format12_*.json'))
        assert len(copies) == 1 and copies[0].read_bytes() == old
        assert json.loads(Path(mod.SAVE_FILE).read_text(encoding='utf-8'))['version'] == 15
        assert app.save_items() and len(list(Path(mod.BACKUP_DIR).glob('liste_vor_format12_*.json'))) == 1

        folder = app.new_folder_object('Projektunterlagen', color='clear', note='Unterlagen und nächste Schritte.')
        task = app.new_item('Ergebnis prüfen')
        entry = app.new_list_object('Wochenplanung', [task], folder_id=folder['id'], color='accent',
                                    note='Die Woche vorbereiten und den nächsten Schritt festhalten.')
        app.folders.append(folder)
        app.lists.append(entry)
        for owner, name in ((folder, 'ordner.txt'), (entry, 'liste.txt'), (task, 'aufgabe.txt')):
            source = Path(tmp)/name
            source.write_text(name + ': Inhalt bleibt erhalten.', encoding='utf-8')
            owner['attachments'] = app._store_pending_attachments([{'name': name, 'pending_path': str(source)}])
        app.set_active_list(entry['id'])
        assert app.save_items()
        expected = {a['storage']: Path(app.resolve_attachment_path(a)).read_bytes()
                    for owner in (folder, entry, task) for a in owner['attachments']}
        backup = Path(tmp)/'container.glidebackup'
        payload = app.partial_backup_payload(folder_ids=[folder['id']])
        app.write_complete_backup(str(backup), payload)
        with zipfile.ZipFile(backup) as archive:
            assert app.validate_backup_schema(json.loads(archive.read('data.json')), portable=True) == set(expected)
            assert all(archive.read(storage) == data for storage, data in expected.items())
        previous = {x['id'] for x in app.lists + app.folders}
        app.import_full_backup(additive=True, path=str(backup))
        added = [x for x in app.lists + app.folders if x['id'] not in previous]
        assert len(added) == 2
        for owner in added:
            assert owner['attachments'] and owner['attachments'][0]['storage'] not in expected
            assert Path(app.resolve_attachment_path(owner['attachments'][0])).read_bytes().startswith(
                owner['attachments'][0]['name'].encode('utf-8'))
        template = app.capture_template(folder_id=folder['id'])
        previous = {x['id'] for x in app.lists + app.folders}
        app.create_list_from_template(template['id'])
        assert len([x for x in app.lists + app.folders if x['id'] not in previous and x['attachments']]) == 2
        app.duplicate_list(entry['id'])
        duplicate = next(x for x in app.lists if x['title'] == entry['title'] + ' (Kopie)')
        assert duplicate['attachments'] == entry['attachments']
        assert duplicate['attachments'] is not entry['attachments']

        # Papierkorb, Neustart-Normalisierung und Wiederherstellung erhalten Metadaten und Bytes.
        app.delete_folder(folder['id'])
        app.load_items()
        deleted_folder = next(x for x in app.trash if (x.get('folder') or {}).get('id') == folder['id'])
        app.write_complete_backup(str(Path(tmp)/'papierkorb.glidebackup'), app.complete_backup_payload())
        with zipfile.ZipFile(Path(tmp)/'papierkorb.glidebackup') as archive:
            assert set(expected) <= set(archive.namelist())
        assert app.restore_trash_entry(deleted_folder['id'])
        folder = app.get_folder(folder['id'])
        entry = next(x for x in app.lists if x['id'] == entry['id'])
        assert folder['attachments'] and entry['attachments']
        bad = app.complete_backup_payload()
        bad['folders'][0]['attachments'] = [{'storage': '../fremd.txt'}]
        try:
            app.validate_backup_schema(bad, portable=True)
            raise AssertionError('Unsicherer Containeranhang akzeptiert')
        except ValueError:
            pass

        # Erledigen, Löschen und endgültiges Entfernen reduzieren keine gebuchten Tageswerte.
        app.set_active_list(entry['id'])
        task = entry['items'][0]
        task['done'] = False
        app.save_items()
        today = date.today().isoformat()
        yesterday = (date.today()-timedelta(days=1)).isoformat()
        app.settings['completion_history'] = {yesterday: 2}
        task['done'] = True
        app.record_completions(set(), [task['id']])
        app.save_items()
        completed = copy.deepcopy(app.settings['completion_history'])
        done_before = app.home_summary()['done']
        app.move_item_to_trash(task['id'])
        app.save_items()
        assert app.home_summary()['done'] == done_before-1
        assert app.settings['completion_history'] == completed == {yesterday: 2, today: 1}
        app.trash = []
        app.save_items()
        app.settings = app.load_settings()
        assert app.settings['completion_history'] == completed
        assert app.yearly_activity_history()[yesterday] >= 2

        # Tatsächliche Dialogaktionen, Farben/Labels/Dateien, Abbruch und beide Themes.
        for i in range(24):
            app.labels.append(app.new_label_object(f'Label {i+1}', None, app.LABEL_COLOR_KEYS[i % len(app.LABEL_COLOR_KEYS)]))
        new_file = Path(tmp)/'Besprechung.txt'
        new_file.write_text('Neuer Anhang aus dem Bearbeitungsfenster.', encoding='utf-8')
        original_dialog = app.run_modal
        original_picker = mod.filedialog.askopenfilenames
        mod.filedialog.askopenfilenames = lambda **kw: (str(new_file),)
        def edit_dialog(dialog, parent=None):
            if os.name == 'nt':
                dialog.attributes('-alpha', 0.0)
            dialog.update()
            widgets = list(descendants(dialog))
            first = next(w for w in widgets if isinstance(w, mod.tk.Entry))
            first.delete(0, 'end')
            first.insert(0, 'Bearbeitete Unterlagen')
            dropdown = next(w for w in widgets if isinstance(w, mod.LabelDropdown))
            dropdown.set_selected_ids([app.labels[-1]['id']])
            color_menu = next(w for w in widgets if isinstance(w, (mod.tk.Menubutton, mod.MacOptionMenu)))
            color_menu.setvar(color_menu.cget('textvariable'), app.LIST_COLOR_CHOICES[1][0])
            buttons = {w.text: w for w in widgets if isinstance(w, mod.RoundedButton)}
            buttons['+ Datei'].command()
            dialog.update()
            assert first.winfo_rootx() < dropdown.winfo_rootx()
            for button in buttons.values():
                assert button.winfo_rootx()+button.winfo_width() <= dialog.winfo_rootx()+dialog.winfo_width()
                assert button.winfo_rooty()+button.winfo_height() <= dialog.winfo_rooty()+dialog.winfo_height()
            capture(dialog, 'bearbeiten-'+app.theme_name)
            dropdown._open_popup()
            dialog.update()
            canvas = dropdown._labels_canvas
            assert canvas.yview()[1] < 1
            chip = dropdown._rows[app.labels[0]['id']]['chip']
            chip.event_generate('<MouseWheel>', delta=-120)
            dialog.update()
            assert canvas.yview()[0] > 0
            canvas.yview_moveto(1)
            last_chip = dropdown._rows[app.labels[-1]['id']]['chip']
            before = canvas.yview()[0]
            last_chip.event_generate('<MouseWheel>', delta=120)
            dialog.update()
            assert canvas.yview()[0] < before
            capture(dropdown._popup, 'labels-'+app.theme_name)
            dropdown._close_popup()
            buttons['Speichern'].command()
        app.run_modal = edit_dialog
        for theme in ('dark', 'light'):
            app.theme_name = theme
            app.apply_theme()
            app.edit_folder_details(folder['id'])
            assert folder['title'] == 'Bearbeitete Unterlagen'
            assert folder['color'] == app.LIST_COLOR_CHOICES[1][1]
            assert folder['labels'] == [app.labels[-1]['id']]
            assert any(a['name'] == new_file.name for a in folder['attachments'])
        app.edit_list_details(entry['id'])
        before = copy.deepcopy(entry)
        def cancel_dialog(dialog, parent=None):
            buttons = {w.text: w for w in descendants(dialog) if isinstance(w, mod.RoundedButton)}
            buttons['+ Datei'].command()
            buttons['Abbrechen'].command()
        app.run_modal = cancel_dialog
        app.edit_list_details(entry['id'])
        assert entry == before
        app.run_modal = original_dialog
        mod.filedialog.askopenfilenames = original_picker

        # Mausrad am unteren Ende direkt über beiden Diagrammen wieder aufwärts.
        for theme in ('dark', 'light'):
            app.theme_name = theme
            app.apply_theme()
            app.set_home_view()
            settle()
            for cls in (mod.YearHeatmap, mod.CompletionChart):
                chart = next(w for w in descendants(app.home_content) if isinstance(w, cls))
                app.home_canvas.yview_moveto(1)
                settle()
                before = app.home_canvas.yview()[0]
                chart.event_generate('<MouseWheel>', delta=120)
                root.update()
                assert app.home_canvas.yview()[0] < before
            heatmap = next(w for w in descendants(app.home_content) if isinstance(w, mod.YearHeatmap))
            for cell in heatmap.find_withtag('day'):
                x1, y1, x2, y2 = heatmap.coords(cell)
                day = date.fromisoformat(heatmap.gettags(cell)[1])
                hover = heatmap.hover_text_at((x1+x2)/2, (y1+y2)/2)
                assert day.strftime('%d.%m.%Y') in hover
                assert ('Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag')[day.weekday()] in hover
            assert heatmap.hover_text_at(-10, -10) == ''
            app.home_canvas.yview_moveto(1)
            # Tooltip-Fenster testen, ohne den echten Mauszeiger zu bewegen.
            for iso in (yesterday, today):
                cell = heatmap.find_withtag(iso)[0]
                x1, y1, x2, y2 = heatmap.coords(cell)
                heatmap.winfo_pointerx = lambda: int(heatmap.winfo_rootx()+(x1+x2)/2)
                heatmap.winfo_pointery = lambda: int(heatmap.winfo_rooty()+(y1+y2)/2)
                heatmap.event_generate('<Motion>', x=int((x1+x2)/2), y=int((y1+y2)/2))
                root.after(550, root.quit)
                root.mainloop()
                tips = [w for w in descendants(heatmap) if isinstance(w, mod.tk.Label)]
                assert len(tips) == 1 and date.fromisoformat(iso).strftime('%d.%m.%Y') in tips[0].cget('text')
            capture(tips[0].winfo_toplevel(), 'tageshinweis-'+theme)
            heatmap.event_generate('<Leave>')
            root.update()
            assert not heatmap.winfo_children()
            capture(root, 'jahresanzeige-'+theme)
            app.set_library_view()
            settle()
            assert app.home_canvas.winfo_width() == app.content_frame.winfo_width()
            if app.home_scrollbar.winfo_ismapped():
                assert app.home_scrollbar.winfo_rootx() > app.home_canvas.winfo_rootx()+app.home_canvas.winfo_width()
            assert all(any(isinstance(w, mod.RoundedButton) and w.text in ('Liste bearbeiten', 'Ordner bearbeiten') for w in descendants(card))
                       for card in app.library_cards)
            capture(root, 'kacheln-'+theme)
            app.templates = app.templates[:2]
            app.set_template_view()
            settle()
            assert app.home_canvas.yview() == (0.0, 1.0)
            assert not app.home_scrollbar.winfo_ismapped()
            app.template_cards[0].event_generate('<MouseWheel>', delta=-120)
            root.update()
            assert app.home_canvas.yview() == (0.0, 1.0)
        # Ein innerhalb derselben Sitzung geöffneter alter Datenordner bekommt
        # seine eigene Migrationskopie, unabhängig vom zuvor geöffneten Ordner.
        other = Path(tmp)/'alte-ablage'
        other.mkdir()
        (other/'liste_speicher.json').write_bytes(old)
        app.change_data_folder(str(other))
        assert app.save_items()
        copies = list((other/'backups').glob('liste_vor_format12_*.json'))
        assert len(copies) == 1 and copies[0].read_bytes() == old
        assert not errors, errors
        print('3.7 OK: Formatmigration mit Originalkopie; Containeranhänge in Teilbackup, Import, Vorlage, Kopie, Papierkorb und Restore; sichere Pfade; Tageszahlen nach Löschen; Seitendetails in beiden Themes; Label- und Diagrammscrollen; Tageshover; volle Kachelbreite; kein Leerraumscrollen.')
    finally:
        app.cancel_pending_callbacks()
        app.release_data_lock()
        root.destroy()
