# Bildnachweise der Vorprüfung 3.5.0

**Diese Aufnahmen entstanden unter Linux mit Tcl/Tk 8.6 und DejaVu Sans, nicht
unter Windows.** Sie belegen Aufbau, Abstände, Farben und Zustände der
Oberfläche – nicht das Aussehen der Schriftzeichen auf einem Windows-Rechner.

Symbolformen sehen unter Windows anders aus, weil dort für einen Teil der
Zeichen eine Ersatzschrift einspringt. Welche das sind, beantwortet
`tests/tools/symbolpruefung.py` auf dem jeweiligen Rechner.

Die maßgeblichen Windows-Aufnahmen entstehen im Vollmodus des Prüflaufs:

    & 'C:\Python312\python.exe' tests/tools/pruefen.py --modus voll --protokoll tests/qa-3.5.0/abschluss

| Datei | Zeigt |
|---|---|
| startseite-oben-dark.png | Kopfzeile mit Uhr, Willkommenskachel, Tagesziel, Schnellzugriffe |
| startseite-unten-dark.png | Zuletzt bearbeitet, Vorlagen, Bestand mit 7-Tage-Diagramm |
| startseite-oben-light.png | dieselbe Ansicht im hellen Theme |
| startseite-unten-light.png | unterer Teil im hellen Theme |
| einstellungen-dark.png | Textlogo mit Farbwahl und Vorschau, tägliche Herausforderung |
| eingabemaske-wiederholung-dark.png | Wiederholung mit Wochentagen und Enddatum |
| liste-faelligkeit-dark.png | Fälligkeitsspalte mit Datum und Uhrzeit, vollständig |
| liste-schmal-860-dark.png | schmales Fenster: Fälligkeit und Labels weichen |

Die Testdaten sind erfunden; es wurden keine echten Nutzerdaten verwendet.
`GLIDE_DATA_DIR` war für jeden Lauf auf ein isoliertes Verzeichnis gesetzt.
