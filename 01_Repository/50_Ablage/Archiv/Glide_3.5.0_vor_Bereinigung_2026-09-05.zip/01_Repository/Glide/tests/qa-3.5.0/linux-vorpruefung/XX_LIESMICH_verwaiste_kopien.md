# Hinweis: verwaiste Kopien

Die Bildnachweise zu 3.5.0 liegen jetzt an ihrem regulären Platz:

    50_Ablage/Screenshots/3.5.0/

Der Unterordner `screenshots/` neben dieser Datei enthält dieselben Aufnahmen
unter anderen Namen und ist damit überflüssig. Er kann gelöscht werden.

Das Prüfprotokoll in diesem Ordner (`ergebnis.json` und die Logdateien) bleibt
hier richtig – es folgt dem Muster von `tests/qa-3.4.0/abschluss/`.
