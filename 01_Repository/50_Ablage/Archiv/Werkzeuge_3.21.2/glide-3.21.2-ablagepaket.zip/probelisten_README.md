# Vorlagen und Probedaten – aktueller Stand

Stand 14.09.2026 · Glide 3.21.2 · Aufgabenformat 15 · Einstellungen 2 · Vorlagen 2

| Datei | Verwendung |
|---|---|
| [Praxisvorlagen](Glide-Praxisvorlagen_3.21.2.glidetemplates) | 16 wiederverwendbare Vorlagen über „Vorlagen → Vorlagen hinzufügen …" |
| [Funktionsvorschau](Glide-Funktionsvorschau_3.21.2.glidebackup) | Künstliche Arbeitslisten über „Listen/Ordner hinzufügen …" ergänzen |
| [Releaseplanung](Glide-Releaseplanung_3.21.2.glidebackup) | Interner Veröffentlichungsplan für Glide, keine Freigabe |

Diese drei Dateien sind die Nutzerkopien der Bestände aus
`01_Repository/Glide/tests/fixtures/beispiele` beziehungsweise
`01_Repository/Glide/src/glide/resources/templates`. Sie tragen denselben Inhalt
und denselben Prüfstand. [Vollständige
Vorlagenanleitung](../01_Repository/Glide/docs/27_VORLAGEN_PRAXISANLEITUNG.md).

## Umfang der Funktionsvorschau

12 Listen einschließlich Eingang, 6 Ordner, **166 Punkte**, 9 Labels und 3
Papierkorbeinträge – eine gelöschte Liste, ein gelöschter Ordner und ein
einzelner Punkt. Alle vier Punktarten kommen vor: 111 Aufgaben, 11 Gruppen, 14
Long-Tasks, 30 Überschriften. Vier echte kleine Textanhänge zeigen Anhänge an
Ordner, Liste und Punkt.

Fälligkeiten liegen an 35 Punkten, davon 7 mit Uhrzeit; 7 Punkte tragen einen
Bearbeitungstag, 6 einen geschätzten Aufwand, 29 eine Wichtigkeit, 107 mindestens
ein Label. Alle sieben Palettenfarben sind vertreten.

## Was sich womit ausprobieren lässt

Die Liste **„Kalender, Erinnerungen und Tagesplanung"** im Ordner
„Website-Betrieb" ist der Prüfbestand für alles seit 3.14. Sie ist absichtlich so
gebaut, dass jede Funktion eine sichtbare Wirkung hat.

| Funktion | Womit | Doku |
|---|---|---|
| Tagesplanung und Tageskapazität | Sechs Punkte auf dem heutigen Bearbeitungstag, Summe **270 Minuten** – einer ohne Schätzung, einer erledigt. Ein Punkt liegt auf morgen für den Tageswechsel. | [3.15](../01_Repository/Glide/docs/39_KAPAZITAET_UND_TAGESPLANUNG_3.15.0.md) |
| Bearbeitungstag und Aufwand | „Grundrisse Parkquartier zeichnen": Bearbeitungstag heute, Aufwand 90 Minuten, Fälligkeit später – die drei Felder sind absichtlich verschieden. | [3.14](../01_Repository/Glide/docs/37_PLANUNG_UND_AUFWAND_3.14.0.md) |
| Erinnerungen, beide Arten | „Rückruf Bauträger" relativ, 30 Minuten vor dem Termin. „Angebotsfrist Parkquartier" fest, am Vortag um 8 Uhr. | [3.8](../01_Repository/Glide/docs/31_ERINNERUNGEN_3.8.0.md) |
| Wiederholungen, alle sechs Arten | täglich, alle 14 Tage mit Ende, Wochentage Mo/Mi mit Ende, wöchentlich, monatlich, jährlich | [3.21](../01_Repository/Glide/docs/45_KALENDERIMPORT_3.21.0.md) |
| Kalenderausgabe als ICS | Liste öffnen, Datei → Kalenderausgabe, Umfang „Aktuelle Liste". Ganztags- und Zeittermine, eine RRULE je Art, VALARM für beide Erinnerungen. | [3.20](../01_Repository/Glide/docs/44_KALENDERAUSGABE_3.20.0.md) |
| Kalenderimport aus ICS | Dieselbe Datei wieder einlesen: Der Bericht muss alle Termine als Duplikate überspringen. Mit ersetzten UIDs entstehen Aufgaben, und das Serienende bleibt erhalten. | [3.21](../01_Repository/Glide/docs/45_KALENDERIMPORT_3.21.0.md) |
| Änderungsverlauf | Ansicht → „Änderungsverlauf …" oder Strg/Cmd+H. Nach dem Import stehen die angelegten Punkte als Sammeleintrag darin. | [3.19](../01_Repository/Glide/docs/43_AENDERUNGSVERLAUF_3.19.0.md) |
| CSV-Import mit Spaltenzuordnung | Eine Probeliste als CSV ausgeben, in einem Tabellenprogramm ergänzen, über Datei → CSV importieren wieder einlesen. | [3.18](../01_Repository/Glide/docs/42_CSV_IMPORT_3.18.0.md) |
| Druck- und PDF-Ausgabe | „Drucken und PDF …", Checkliste wählen, im Druckdialog als PDF speichern. | [3.17](../01_Repository/Glide/docs/41_DRUCK_UND_PDF_3.17.0.md) |
| Vollständiges App-Backup | Erst „Vollständiges App-Backup speichern …", dann **in einer getrennten Ablage** wiederherstellen und die Inhaltsvorschau mit dem Bestand vergleichen. | [3.16](../01_Repository/Glide/docs/40_APP_BACKUP_3.16.0.md) |
| Tabellenansicht, „Mein Tag", Schnellerfassung, Filter, Reiter, Pinnwände | Mit allen Listen dieser Datei. Spaltenauswahl und Tagesauswahl sind persönliche Einstellungen und stehen **nicht** im Aufgabenbackup. | [3.9](../01_Repository/Glide/docs/32_UI_UND_BEDIENUNG_3.9.0.md) |

## Der Kalenderrundlauf in vier Schritten

Die Liste enthält diese Anleitung auch als Long-Task, damit sie beim Ausprobieren
in der App steht:

1. Liste öffnen, Datei → Kalenderausgabe als ICS, Umfang „Aktuelle Liste".
2. Datei im Texteditor ansehen: Ganztags- und Zeittermine, eine `RRULE` je
   Wiederholungsart, `VALARM` für beide Erinnerungen. `UNTIL` steht **ohne „Z"** –
   bis 3.21.0 stand dort ein UTC-Zeitpunkt, wodurch sich das Serienende beim
   Wiedereinlesen um einen Tag verschob.
3. Datei → „Kalenderdatei (ICS) importieren …", dieselbe Datei wählen. Der
   Bericht muss **alle** Termine als Duplikate überspringen: Die eigenen UIDs
   werden erkannt, der Rundlauf legt keine Kopien an.
4. Gegentest: die `UID:`-Zeilen im Editor ersetzen und erneut importieren. Jetzt
   entstehen Aufgaben, und das Enddatum der Wochentagsserie muss unverändert
   bleiben – auch wenn die Systemzeitzone gewechselt wird.

## Releaseplanung

3 Arbeitslisten plus Eingang, 1 Ordner, 159 Punkte. Planungsstichtag 14.09.2026;
Recherche historisch 04.09.2026, Microsoft-Textvorgaben 05.09.2026. Die Fristen
sind unverbindliche Planungsvorschläge, keine Zusagen. Storevorgaben vor einer
Veröffentlichung erneut prüfen.

## Fristen, Formate, Archiv

Backupfristen beziehen sich auf den Erzeugungstag 14.09.2026. Anders als relative
Vorlagenfristen verschieben Backups sie beim Import **nicht** – ein am
Erzeugungstag fälliger Punkt ist später überfällig. Die Dateien setzen
Aufgabenformat 15 voraus und benötigen Glide ab 3.19; ältere Fassungen lesen sie
nicht.

Alle überholten Fassungen liegen in [Archiv](Archiv/); gelöscht wurde nichts.
Technische Referenzformate für Migrationsprüfungen bleiben zusätzlich unter
`01_Repository/Glide/tests/fixtures` erhalten.

## Umgang mit echten Daten

Diese Dateien sind künstlich. Zum Ausprobieren einen getrennten Datenordner
verwenden (`GLIDE_DATA_DIR`) oder vorher ein eigenes Backup anlegen: Das
Wiederherstellen eines App-Backups **ersetzt** den vorhandenen Bestand. Keine
dieser Dateien enthält echte Personen-, Kunden- oder Objektdaten.
